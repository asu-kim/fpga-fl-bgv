// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xfc_kernel.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XFc_kernel_CfgInitialize(XFc_kernel *InstancePtr, XFc_kernel_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XFc_kernel_Start(XFc_kernel *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFc_kernel_ReadReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_AP_CTRL) & 0x80;
    XFc_kernel_WriteReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XFc_kernel_IsDone(XFc_kernel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFc_kernel_ReadReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XFc_kernel_IsIdle(XFc_kernel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFc_kernel_ReadReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XFc_kernel_IsReady(XFc_kernel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFc_kernel_ReadReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XFc_kernel_Continue(XFc_kernel *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFc_kernel_ReadReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_AP_CTRL) & 0x80;
    XFc_kernel_WriteReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_AP_CTRL, Data | 0x10);
}

void XFc_kernel_EnableAutoRestart(XFc_kernel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFc_kernel_WriteReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XFc_kernel_DisableAutoRestart(XFc_kernel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFc_kernel_WriteReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_AP_CTRL, 0);
}

void XFc_kernel_Set_enc_weights(XFc_kernel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFc_kernel_WriteReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_ENC_WEIGHTS_DATA, (u32)(Data));
    XFc_kernel_WriteReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_ENC_WEIGHTS_DATA + 4, (u32)(Data >> 32));
}

u64 XFc_kernel_Get_enc_weights(XFc_kernel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFc_kernel_ReadReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_ENC_WEIGHTS_DATA);
    Data += (u64)XFc_kernel_ReadReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_ENC_WEIGHTS_DATA + 4) << 32;
    return Data;
}

void XFc_kernel_Set_enc_bias(XFc_kernel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFc_kernel_WriteReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_ENC_BIAS_DATA, (u32)(Data));
    XFc_kernel_WriteReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_ENC_BIAS_DATA + 4, (u32)(Data >> 32));
}

u64 XFc_kernel_Get_enc_bias(XFc_kernel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFc_kernel_ReadReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_ENC_BIAS_DATA);
    Data += (u64)XFc_kernel_ReadReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_ENC_BIAS_DATA + 4) << 32;
    return Data;
}

void XFc_kernel_Set_enc_input(XFc_kernel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFc_kernel_WriteReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_ENC_INPUT_DATA, (u32)(Data));
    XFc_kernel_WriteReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_ENC_INPUT_DATA + 4, (u32)(Data >> 32));
}

u64 XFc_kernel_Get_enc_input(XFc_kernel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFc_kernel_ReadReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_ENC_INPUT_DATA);
    Data += (u64)XFc_kernel_ReadReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_ENC_INPUT_DATA + 4) << 32;
    return Data;
}

void XFc_kernel_Set_enc_output(XFc_kernel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFc_kernel_WriteReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_ENC_OUTPUT_DATA, (u32)(Data));
    XFc_kernel_WriteReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_ENC_OUTPUT_DATA + 4, (u32)(Data >> 32));
}

u64 XFc_kernel_Get_enc_output(XFc_kernel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFc_kernel_ReadReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_ENC_OUTPUT_DATA);
    Data += (u64)XFc_kernel_ReadReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_ENC_OUTPUT_DATA + 4) << 32;
    return Data;
}

void XFc_kernel_Set_use_relu(XFc_kernel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFc_kernel_WriteReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_USE_RELU_DATA, Data);
}

u32 XFc_kernel_Get_use_relu(XFc_kernel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFc_kernel_ReadReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_USE_RELU_DATA);
    return Data;
}

void XFc_kernel_InterruptGlobalEnable(XFc_kernel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFc_kernel_WriteReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_GIE, 1);
}

void XFc_kernel_InterruptGlobalDisable(XFc_kernel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFc_kernel_WriteReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_GIE, 0);
}

void XFc_kernel_InterruptEnable(XFc_kernel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFc_kernel_ReadReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_IER);
    XFc_kernel_WriteReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_IER, Register | Mask);
}

void XFc_kernel_InterruptDisable(XFc_kernel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFc_kernel_ReadReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_IER);
    XFc_kernel_WriteReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_IER, Register & (~Mask));
}

void XFc_kernel_InterruptClear(XFc_kernel *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFc_kernel_WriteReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_ISR, Mask);
}

u32 XFc_kernel_InterruptGetEnabled(XFc_kernel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFc_kernel_ReadReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_IER);
}

u32 XFc_kernel_InterruptGetStatus(XFc_kernel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFc_kernel_ReadReg(InstancePtr->Control_BaseAddress, XFC_KERNEL_CONTROL_ADDR_ISR);
}

