// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xfc_kernel.h"

extern XFc_kernel_Config XFc_kernel_ConfigTable[];

#ifdef SDT
XFc_kernel_Config *XFc_kernel_LookupConfig(UINTPTR BaseAddress) {
	XFc_kernel_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XFc_kernel_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XFc_kernel_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XFc_kernel_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XFc_kernel_Initialize(XFc_kernel *InstancePtr, UINTPTR BaseAddress) {
	XFc_kernel_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XFc_kernel_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XFc_kernel_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XFc_kernel_Config *XFc_kernel_LookupConfig(u16 DeviceId) {
	XFc_kernel_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XFC_KERNEL_NUM_INSTANCES; Index++) {
		if (XFc_kernel_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XFc_kernel_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XFc_kernel_Initialize(XFc_kernel *InstancePtr, u16 DeviceId) {
	XFc_kernel_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XFc_kernel_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XFc_kernel_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

