// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xavg_pool_kernel.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XAvg_pool_kernel_CfgInitialize(XAvg_pool_kernel *InstancePtr, XAvg_pool_kernel_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XAvg_pool_kernel_Start(XAvg_pool_kernel *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAvg_pool_kernel_ReadReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_AP_CTRL) & 0x80;
    XAvg_pool_kernel_WriteReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XAvg_pool_kernel_IsDone(XAvg_pool_kernel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAvg_pool_kernel_ReadReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XAvg_pool_kernel_IsIdle(XAvg_pool_kernel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAvg_pool_kernel_ReadReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XAvg_pool_kernel_IsReady(XAvg_pool_kernel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAvg_pool_kernel_ReadReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XAvg_pool_kernel_Continue(XAvg_pool_kernel *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAvg_pool_kernel_ReadReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_AP_CTRL) & 0x80;
    XAvg_pool_kernel_WriteReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_AP_CTRL, Data | 0x10);
}

void XAvg_pool_kernel_EnableAutoRestart(XAvg_pool_kernel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAvg_pool_kernel_WriteReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XAvg_pool_kernel_DisableAutoRestart(XAvg_pool_kernel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAvg_pool_kernel_WriteReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_AP_CTRL, 0);
}

void XAvg_pool_kernel_Set_enc_input(XAvg_pool_kernel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAvg_pool_kernel_WriteReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_ENC_INPUT_DATA, (u32)(Data));
    XAvg_pool_kernel_WriteReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_ENC_INPUT_DATA + 4, (u32)(Data >> 32));
}

u64 XAvg_pool_kernel_Get_enc_input(XAvg_pool_kernel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAvg_pool_kernel_ReadReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_ENC_INPUT_DATA);
    Data += (u64)XAvg_pool_kernel_ReadReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_ENC_INPUT_DATA + 4) << 32;
    return Data;
}

void XAvg_pool_kernel_Set_enc_output(XAvg_pool_kernel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAvg_pool_kernel_WriteReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_ENC_OUTPUT_DATA, (u32)(Data));
    XAvg_pool_kernel_WriteReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_ENC_OUTPUT_DATA + 4, (u32)(Data >> 32));
}

u64 XAvg_pool_kernel_Get_enc_output(XAvg_pool_kernel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAvg_pool_kernel_ReadReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_ENC_OUTPUT_DATA);
    Data += (u64)XAvg_pool_kernel_ReadReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_ENC_OUTPUT_DATA + 4) << 32;
    return Data;
}

void XAvg_pool_kernel_InterruptGlobalEnable(XAvg_pool_kernel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAvg_pool_kernel_WriteReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_GIE, 1);
}

void XAvg_pool_kernel_InterruptGlobalDisable(XAvg_pool_kernel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAvg_pool_kernel_WriteReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_GIE, 0);
}

void XAvg_pool_kernel_InterruptEnable(XAvg_pool_kernel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAvg_pool_kernel_ReadReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_IER);
    XAvg_pool_kernel_WriteReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_IER, Register | Mask);
}

void XAvg_pool_kernel_InterruptDisable(XAvg_pool_kernel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAvg_pool_kernel_ReadReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_IER);
    XAvg_pool_kernel_WriteReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_IER, Register & (~Mask));
}

void XAvg_pool_kernel_InterruptClear(XAvg_pool_kernel *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAvg_pool_kernel_WriteReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_ISR, Mask);
}

u32 XAvg_pool_kernel_InterruptGetEnabled(XAvg_pool_kernel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAvg_pool_kernel_ReadReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_IER);
}

u32 XAvg_pool_kernel_InterruptGetStatus(XAvg_pool_kernel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAvg_pool_kernel_ReadReg(InstancePtr->Control_BaseAddress, XAVG_POOL_KERNEL_CONTROL_ADDR_ISR);
}

