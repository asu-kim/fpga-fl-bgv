// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XAVG_POOL_KERNEL_H
#define XAVG_POOL_KERNEL_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xavg_pool_kernel_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XAvg_pool_kernel_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XAvg_pool_kernel;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XAvg_pool_kernel_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XAvg_pool_kernel_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XAvg_pool_kernel_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XAvg_pool_kernel_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XAvg_pool_kernel_Initialize(XAvg_pool_kernel *InstancePtr, UINTPTR BaseAddress);
XAvg_pool_kernel_Config* XAvg_pool_kernel_LookupConfig(UINTPTR BaseAddress);
#else
int XAvg_pool_kernel_Initialize(XAvg_pool_kernel *InstancePtr, u16 DeviceId);
XAvg_pool_kernel_Config* XAvg_pool_kernel_LookupConfig(u16 DeviceId);
#endif
int XAvg_pool_kernel_CfgInitialize(XAvg_pool_kernel *InstancePtr, XAvg_pool_kernel_Config *ConfigPtr);
#else
int XAvg_pool_kernel_Initialize(XAvg_pool_kernel *InstancePtr, const char* InstanceName);
int XAvg_pool_kernel_Release(XAvg_pool_kernel *InstancePtr);
#endif

void XAvg_pool_kernel_Start(XAvg_pool_kernel *InstancePtr);
u32 XAvg_pool_kernel_IsDone(XAvg_pool_kernel *InstancePtr);
u32 XAvg_pool_kernel_IsIdle(XAvg_pool_kernel *InstancePtr);
u32 XAvg_pool_kernel_IsReady(XAvg_pool_kernel *InstancePtr);
void XAvg_pool_kernel_Continue(XAvg_pool_kernel *InstancePtr);
void XAvg_pool_kernel_EnableAutoRestart(XAvg_pool_kernel *InstancePtr);
void XAvg_pool_kernel_DisableAutoRestart(XAvg_pool_kernel *InstancePtr);

void XAvg_pool_kernel_Set_enc_input(XAvg_pool_kernel *InstancePtr, u64 Data);
u64 XAvg_pool_kernel_Get_enc_input(XAvg_pool_kernel *InstancePtr);
void XAvg_pool_kernel_Set_enc_output(XAvg_pool_kernel *InstancePtr, u64 Data);
u64 XAvg_pool_kernel_Get_enc_output(XAvg_pool_kernel *InstancePtr);

void XAvg_pool_kernel_InterruptGlobalEnable(XAvg_pool_kernel *InstancePtr);
void XAvg_pool_kernel_InterruptGlobalDisable(XAvg_pool_kernel *InstancePtr);
void XAvg_pool_kernel_InterruptEnable(XAvg_pool_kernel *InstancePtr, u32 Mask);
void XAvg_pool_kernel_InterruptDisable(XAvg_pool_kernel *InstancePtr, u32 Mask);
void XAvg_pool_kernel_InterruptClear(XAvg_pool_kernel *InstancePtr, u32 Mask);
u32 XAvg_pool_kernel_InterruptGetEnabled(XAvg_pool_kernel *InstancePtr);
u32 XAvg_pool_kernel_InterruptGetStatus(XAvg_pool_kernel *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
