// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xavg_pool_kernel.h"

extern XAvg_pool_kernel_Config XAvg_pool_kernel_ConfigTable[];

#ifdef SDT
XAvg_pool_kernel_Config *XAvg_pool_kernel_LookupConfig(UINTPTR BaseAddress) {
	XAvg_pool_kernel_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XAvg_pool_kernel_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XAvg_pool_kernel_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XAvg_pool_kernel_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XAvg_pool_kernel_Initialize(XAvg_pool_kernel *InstancePtr, UINTPTR BaseAddress) {
	XAvg_pool_kernel_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XAvg_pool_kernel_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XAvg_pool_kernel_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XAvg_pool_kernel_Config *XAvg_pool_kernel_LookupConfig(u16 DeviceId) {
	XAvg_pool_kernel_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XAVG_POOL_KERNEL_NUM_INSTANCES; Index++) {
		if (XAvg_pool_kernel_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XAvg_pool_kernel_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XAvg_pool_kernel_Initialize(XAvg_pool_kernel *InstancePtr, u16 DeviceId) {
	XAvg_pool_kernel_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XAvg_pool_kernel_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XAvg_pool_kernel_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

