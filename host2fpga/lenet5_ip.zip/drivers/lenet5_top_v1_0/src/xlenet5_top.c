// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xlenet5_top.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XLenet5_top_CfgInitialize(XLenet5_top *InstancePtr, XLenet5_top_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XLenet5_top_Start(XLenet5_top *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_AP_CTRL) & 0x80;
    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XLenet5_top_IsDone(XLenet5_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XLenet5_top_IsIdle(XLenet5_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XLenet5_top_IsReady(XLenet5_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XLenet5_top_Continue(XLenet5_top *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_AP_CTRL) & 0x80;
    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_AP_CTRL, Data | 0x10);
}

void XLenet5_top_EnableAutoRestart(XLenet5_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XLenet5_top_DisableAutoRestart(XLenet5_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_AP_CTRL, 0);
}

void XLenet5_top_Set_image_r(XLenet5_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_IMAGE_R_DATA, (u32)(Data));
    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_IMAGE_R_DATA + 4, (u32)(Data >> 32));
}

u64 XLenet5_top_Get_image_r(XLenet5_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_IMAGE_R_DATA);
    Data += (u64)XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_IMAGE_R_DATA + 4) << 32;
    return Data;
}

void XLenet5_top_Set_enc_conv1_weight(XLenet5_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_CONV1_WEIGHT_DATA, (u32)(Data));
    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_CONV1_WEIGHT_DATA + 4, (u32)(Data >> 32));
}

u64 XLenet5_top_Get_enc_conv1_weight(XLenet5_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_CONV1_WEIGHT_DATA);
    Data += (u64)XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_CONV1_WEIGHT_DATA + 4) << 32;
    return Data;
}

void XLenet5_top_Set_enc_conv1_bias(XLenet5_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_CONV1_BIAS_DATA, (u32)(Data));
    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_CONV1_BIAS_DATA + 4, (u32)(Data >> 32));
}

u64 XLenet5_top_Get_enc_conv1_bias(XLenet5_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_CONV1_BIAS_DATA);
    Data += (u64)XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_CONV1_BIAS_DATA + 4) << 32;
    return Data;
}

void XLenet5_top_Set_enc_conv2_weight(XLenet5_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_CONV2_WEIGHT_DATA, (u32)(Data));
    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_CONV2_WEIGHT_DATA + 4, (u32)(Data >> 32));
}

u64 XLenet5_top_Get_enc_conv2_weight(XLenet5_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_CONV2_WEIGHT_DATA);
    Data += (u64)XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_CONV2_WEIGHT_DATA + 4) << 32;
    return Data;
}

void XLenet5_top_Set_enc_conv2_bias(XLenet5_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_CONV2_BIAS_DATA, (u32)(Data));
    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_CONV2_BIAS_DATA + 4, (u32)(Data >> 32));
}

u64 XLenet5_top_Get_enc_conv2_bias(XLenet5_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_CONV2_BIAS_DATA);
    Data += (u64)XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_CONV2_BIAS_DATA + 4) << 32;
    return Data;
}

void XLenet5_top_Set_enc_fc1_weight(XLenet5_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC1_WEIGHT_DATA, (u32)(Data));
    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC1_WEIGHT_DATA + 4, (u32)(Data >> 32));
}

u64 XLenet5_top_Get_enc_fc1_weight(XLenet5_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC1_WEIGHT_DATA);
    Data += (u64)XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC1_WEIGHT_DATA + 4) << 32;
    return Data;
}

void XLenet5_top_Set_enc_fc1_bias(XLenet5_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC1_BIAS_DATA, (u32)(Data));
    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC1_BIAS_DATA + 4, (u32)(Data >> 32));
}

u64 XLenet5_top_Get_enc_fc1_bias(XLenet5_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC1_BIAS_DATA);
    Data += (u64)XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC1_BIAS_DATA + 4) << 32;
    return Data;
}

void XLenet5_top_Set_enc_fc2_weight(XLenet5_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC2_WEIGHT_DATA, (u32)(Data));
    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC2_WEIGHT_DATA + 4, (u32)(Data >> 32));
}

u64 XLenet5_top_Get_enc_fc2_weight(XLenet5_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC2_WEIGHT_DATA);
    Data += (u64)XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC2_WEIGHT_DATA + 4) << 32;
    return Data;
}

void XLenet5_top_Set_enc_fc2_bias(XLenet5_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC2_BIAS_DATA, (u32)(Data));
    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC2_BIAS_DATA + 4, (u32)(Data >> 32));
}

u64 XLenet5_top_Get_enc_fc2_bias(XLenet5_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC2_BIAS_DATA);
    Data += (u64)XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC2_BIAS_DATA + 4) << 32;
    return Data;
}

void XLenet5_top_Set_enc_fc3_weight(XLenet5_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC3_WEIGHT_DATA, (u32)(Data));
    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC3_WEIGHT_DATA + 4, (u32)(Data >> 32));
}

u64 XLenet5_top_Get_enc_fc3_weight(XLenet5_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC3_WEIGHT_DATA);
    Data += (u64)XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC3_WEIGHT_DATA + 4) << 32;
    return Data;
}

void XLenet5_top_Set_enc_fc3_bias(XLenet5_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC3_BIAS_DATA, (u32)(Data));
    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC3_BIAS_DATA + 4, (u32)(Data >> 32));
}

u64 XLenet5_top_Get_enc_fc3_bias(XLenet5_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC3_BIAS_DATA);
    Data += (u64)XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ENC_FC3_BIAS_DATA + 4) << 32;
    return Data;
}

void XLenet5_top_Set_logits(XLenet5_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_LOGITS_DATA, (u32)(Data));
    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_LOGITS_DATA + 4, (u32)(Data >> 32));
}

u64 XLenet5_top_Get_logits(XLenet5_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_LOGITS_DATA);
    Data += (u64)XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_LOGITS_DATA + 4) << 32;
    return Data;
}

void XLenet5_top_InterruptGlobalEnable(XLenet5_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_GIE, 1);
}

void XLenet5_top_InterruptGlobalDisable(XLenet5_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_GIE, 0);
}

void XLenet5_top_InterruptEnable(XLenet5_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_IER);
    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_IER, Register | Mask);
}

void XLenet5_top_InterruptDisable(XLenet5_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_IER);
    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_IER, Register & (~Mask));
}

void XLenet5_top_InterruptClear(XLenet5_top *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLenet5_top_WriteReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ISR, Mask);
}

u32 XLenet5_top_InterruptGetEnabled(XLenet5_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_IER);
}

u32 XLenet5_top_InterruptGetStatus(XLenet5_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLenet5_top_ReadReg(InstancePtr->Control_BaseAddress, XLENET5_TOP_CONTROL_ADDR_ISR);
}

