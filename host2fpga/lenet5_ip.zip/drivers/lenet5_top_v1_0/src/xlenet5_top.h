// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XLENET5_TOP_H
#define XLENET5_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xlenet5_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XLenet5_top_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XLenet5_top;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XLenet5_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XLenet5_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XLenet5_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XLenet5_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XLenet5_top_Initialize(XLenet5_top *InstancePtr, UINTPTR BaseAddress);
XLenet5_top_Config* XLenet5_top_LookupConfig(UINTPTR BaseAddress);
#else
int XLenet5_top_Initialize(XLenet5_top *InstancePtr, u16 DeviceId);
XLenet5_top_Config* XLenet5_top_LookupConfig(u16 DeviceId);
#endif
int XLenet5_top_CfgInitialize(XLenet5_top *InstancePtr, XLenet5_top_Config *ConfigPtr);
#else
int XLenet5_top_Initialize(XLenet5_top *InstancePtr, const char* InstanceName);
int XLenet5_top_Release(XLenet5_top *InstancePtr);
#endif

void XLenet5_top_Start(XLenet5_top *InstancePtr);
u32 XLenet5_top_IsDone(XLenet5_top *InstancePtr);
u32 XLenet5_top_IsIdle(XLenet5_top *InstancePtr);
u32 XLenet5_top_IsReady(XLenet5_top *InstancePtr);
void XLenet5_top_Continue(XLenet5_top *InstancePtr);
void XLenet5_top_EnableAutoRestart(XLenet5_top *InstancePtr);
void XLenet5_top_DisableAutoRestart(XLenet5_top *InstancePtr);

void XLenet5_top_Set_image_r(XLenet5_top *InstancePtr, u64 Data);
u64 XLenet5_top_Get_image_r(XLenet5_top *InstancePtr);
void XLenet5_top_Set_enc_conv1_weight(XLenet5_top *InstancePtr, u64 Data);
u64 XLenet5_top_Get_enc_conv1_weight(XLenet5_top *InstancePtr);
void XLenet5_top_Set_enc_conv1_bias(XLenet5_top *InstancePtr, u64 Data);
u64 XLenet5_top_Get_enc_conv1_bias(XLenet5_top *InstancePtr);
void XLenet5_top_Set_enc_conv2_weight(XLenet5_top *InstancePtr, u64 Data);
u64 XLenet5_top_Get_enc_conv2_weight(XLenet5_top *InstancePtr);
void XLenet5_top_Set_enc_conv2_bias(XLenet5_top *InstancePtr, u64 Data);
u64 XLenet5_top_Get_enc_conv2_bias(XLenet5_top *InstancePtr);
void XLenet5_top_Set_enc_fc1_weight(XLenet5_top *InstancePtr, u64 Data);
u64 XLenet5_top_Get_enc_fc1_weight(XLenet5_top *InstancePtr);
void XLenet5_top_Set_enc_fc1_bias(XLenet5_top *InstancePtr, u64 Data);
u64 XLenet5_top_Get_enc_fc1_bias(XLenet5_top *InstancePtr);
void XLenet5_top_Set_enc_fc2_weight(XLenet5_top *InstancePtr, u64 Data);
u64 XLenet5_top_Get_enc_fc2_weight(XLenet5_top *InstancePtr);
void XLenet5_top_Set_enc_fc2_bias(XLenet5_top *InstancePtr, u64 Data);
u64 XLenet5_top_Get_enc_fc2_bias(XLenet5_top *InstancePtr);
void XLenet5_top_Set_enc_fc3_weight(XLenet5_top *InstancePtr, u64 Data);
u64 XLenet5_top_Get_enc_fc3_weight(XLenet5_top *InstancePtr);
void XLenet5_top_Set_enc_fc3_bias(XLenet5_top *InstancePtr, u64 Data);
u64 XLenet5_top_Get_enc_fc3_bias(XLenet5_top *InstancePtr);
void XLenet5_top_Set_logits(XLenet5_top *InstancePtr, u64 Data);
u64 XLenet5_top_Get_logits(XLenet5_top *InstancePtr);

void XLenet5_top_InterruptGlobalEnable(XLenet5_top *InstancePtr);
void XLenet5_top_InterruptGlobalDisable(XLenet5_top *InstancePtr);
void XLenet5_top_InterruptEnable(XLenet5_top *InstancePtr, u32 Mask);
void XLenet5_top_InterruptDisable(XLenet5_top *InstancePtr, u32 Mask);
void XLenet5_top_InterruptClear(XLenet5_top *InstancePtr, u32 Mask);
u32 XLenet5_top_InterruptGetEnabled(XLenet5_top *InstancePtr);
u32 XLenet5_top_InterruptGetStatus(XLenet5_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
